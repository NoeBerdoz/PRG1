/*------------------
 Laboratoire : 1a
 Auteur(s) : Ophélie, Gwenaël, Noé
 Date : 26.09.22
 But : calcule le temps du trajet du robot pour atteindre l'objet
 Remarque(s) :
 -----------------*/
#include <iostream>
#include <cmath>

int main() {
    // inputs
    double distanceXBetweenStartingPointAndObject = 3;
    double distanceYBetweenStartingPointAndObject = 10;
    double robotSpeedRoad = 5;
    double robotSpeedRock = 2;
    double distanceYBetweenStartingPointAndRoadExit = 6;
    // methods
    double distanceYBetweenRoadExitAndObject = distanceYBetweenStartingPointAndObject - distanceYBetweenStartingPointAndRoadExit;
    double distanceBetweenRoadExitAndObject = sqrt(
            pow(distanceYBetweenRoadExitAndObject, 2) + pow(distanceXBetweenStartingPointAndObject, 2)
    );
    double rockTravelTime = distanceBetweenRoadExitAndObject / robotSpeedRock;
    double roadTravelTime = distanceYBetweenStartingPointAndRoadExit / robotSpeedRoad;
    double totalTravelTime = roadTravelTime + rockTravelTime;
    // outputs
    std::cout << totalTravelTime << std::endl;
    return 0;
}


